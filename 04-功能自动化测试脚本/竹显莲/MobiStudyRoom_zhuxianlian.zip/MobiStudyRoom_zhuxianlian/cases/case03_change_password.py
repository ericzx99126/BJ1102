import time
import unittest
import sys
from tools import open_app


class Change(unittest.TestCase):
    '''修改密码'''
    def setUp(self):
        driver = open_app()
        self.driver = driver
        self.cls_name = self.__class__.__name__

    def tearDown(self):
        driver = self.driver
        # 密码重新修改回来，为了方便测试
        driver.find_element_by_id('com.offcn.yidongzixishi:id/cancel').click()
        driver.find_element_by_id('com.offcn.yidongzixishi:id/iv_mine').click()
        driver.find_element_by_id("com.offcn.yidongzixishi:id/mineSettting").click()
        driver.find_element_by_id("com.offcn.yidongzixishi:id/rlModifyPwd").click()
        driver.find_element_by_id("com.offcn.yidongzixishi:id/et_pwd").send_keys("123456")
        driver.find_element_by_id("com.offcn.yidongzixishi:id/et_confirm_pwd").send_keys("bamboo1997")
        driver.find_element_by_class_name('android.widget.Button').click()
        driver.find_element_by_id("com.offcn.yidongzixishi:id/btn_login").click()
        driver.find_element_by_id('com.offcn.yidongzixishi:id/et_pwd').send_keys('bamboo1997')
        driver.find_element_by_id("com.offcn.yidongzixishi:id/btn_login").click()
        time.sleep(3)
        self.driver.quit()

    def test_case(self):
        driver = self.driver
        mtd_name = sys._getframe().f_code.co_name

        try:

            driver.find_element_by_id('com.offcn.yidongzixishi:id/skip').click()
            driver.find_element_by_id('com.offcn.yidongzixishi:id/et_phone').send_keys('18336281141')
            driver.find_element_by_id('com.offcn.yidongzixishi:id/et_pwd').send_keys('bamboo1997')
            driver.find_element_by_xpath('//android.widget.Button[@index="5" and @text="立即登录"]').click()
            driver.find_elements_by_id('com.offcn.yidongzixishi:id/llExam')[0].click()

            # 取消广告弹窗
            driver.find_element_by_id('com.offcn.yidongzixishi:id/cancel').click()

            driver.find_element_by_id('com.offcn.yidongzixishi:id/iv_mine').click()
            driver.find_element_by_id("com.offcn.yidongzixishi:id/mineSettting").click()
            driver.find_element_by_id("com.offcn.yidongzixishi:id/rlModifyPwd").click()
            driver.find_element_by_id("com.offcn.yidongzixishi:id/et_pwd").send_keys("bamboo1997")
            driver.find_element_by_id("com.offcn.yidongzixishi:id/et_confirm_pwd").send_keys("123456")
            driver.find_element_by_class_name('android.widget.Button').click()

            xg = driver.find_element_by_id('com.offcn.yidongzixishi:id/tv_content').text
            self.assertEqual('修改成功', xg, msg='修改密码失败')

            time.sleep(3)
            driver.find_element_by_id('com.offcn.yidongzixishi:id/et_pwd').send_keys('123456')
            driver.find_element_by_id("com.offcn.yidongzixishi:id/btn_login").click()



        except AssertionError:
            driver.save_screenshot(f'./pics/{self.cls_name}_{mtd_name}_修改密码失败.png')
            raise

        except Exception:
            driver.save_screenshot(f'./pics/{self.cls_name}_{mtd_name}_其他错误.png')
            raise

