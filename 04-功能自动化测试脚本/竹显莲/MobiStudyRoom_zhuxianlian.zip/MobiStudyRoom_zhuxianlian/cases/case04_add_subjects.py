import time
import unittest
import sys
from tools import open_app


class Asub(unittest.TestCase):
    '''添加和删除考试科目是否成功'''
    def setUp(self):
        driver = open_app()
        self.driver = driver
        driver.find_element_by_id('com.offcn.yidongzixishi:id/skip').click()
        driver.find_element_by_id('com.offcn.yidongzixishi:id/et_phone').send_keys('18336281141')
        driver.find_element_by_id('com.offcn.yidongzixishi:id/et_pwd').send_keys('bamboo1997')
        driver.find_element_by_xpath('//android.widget.Button[@index="5" and @text="立即登录"]').click()
        driver.find_elements_by_id('com.offcn.yidongzixishi:id/llExam')[0].click()

        # 取消广告弹窗
        driver.find_element_by_id('com.offcn.yidongzixishi:id/cancel').click()

        self.cls_name = self.__class__.__name__

    def tearDown(self):
        time.sleep(3)
        self.driver.quit()

    def test_case01(self):
        '''添加考试科目是否成功'''
        driver = self.driver
        mtd_name = sys._getframe().f_code.co_name

        try:

            driver.find_element_by_id('com.offcn.yidongzixishi:id/tv_type').click()
            driver.find_element_by_id('com.offcn.yidongzixishi:id/iv_head_commit').click()
            driver.find_elements_by_id('com.offcn.yidongzixishi:id/llExam')[2].click()
            driver.find_element_by_id('com.offcn.yidongzixishi:id/headRight').click()

            tj = driver.find_elements_by_id('com.offcn.yidongzixishi:id/examName')[1].text
            self.assertEqual('事业单位', tj, msg='添加考试科目失败')

        except AssertionError:
            driver.save_screenshot(f'./pics/{self.cls_name}_{mtd_name}_添加考试科目失败.png')
            raise

        except Exception:
            driver.save_screenshot(f'./pics/{self.cls_name}_{mtd_name}_其他错误.png')
            raise


    def test_case02(self):
        '''删除考试科目是否成功'''
        driver = self.driver
        mtd_name = sys._getframe().f_code.co_name

        try:
            # 先添加后删除
            driver.find_element_by_id('com.offcn.yidongzixishi:id/tv_type').click()
            driver.find_element_by_id('com.offcn.yidongzixishi:id/iv_head_commit').click()
            driver.find_elements_by_id('com.offcn.yidongzixishi:id/llExam')[2].click()
            driver.find_element_by_id('com.offcn.yidongzixishi:id/headRight').click()

            driver.find_element_by_id('com.offcn.yidongzixishi:id/headBack').click()

            driver.find_element_by_id('com.offcn.yidongzixishi:id/iv_mine').click()
            driver.find_element_by_id('com.offcn.yidongzixishi:id/examType').click()
            driver.swipe(650, 328, 391, 355, duration=1000)
            driver.find_element_by_xpath('//android.widget.Button[@text="删除"]').click()
            time.sleep(2)

        except AssertionError:
            driver.save_screenshot(f'./pics/{self.cls_name}_{mtd_name}_删除考试科目失败.png')
            raise

        except Exception:
            driver.save_screenshot(f'./pics/{self.cls_name}_{mtd_name}_其他错误.png')
            raise







