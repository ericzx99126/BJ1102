import time
import unittest
import sys
from tools import open_app


class Login(unittest.TestCase):
    '''登录'''
    def setUp(self):
        driver = open_app()
        self.driver = driver
        self.cls_name = self.__class__.__name__

    def tearDown(self):
        time.sleep(3)
        self.driver.quit()

    def test_case(self):
        '''正常流-手机号密码都正确'''
        driver = self.driver
        mtd_name = sys._getframe().f_code.co_name

        try:
            driver.find_element_by_id('com.offcn.yidongzixishi:id/skip').click()
            driver.find_element_by_id('com.offcn.yidongzixishi:id/et_phone').send_keys('18336281141')
            driver.find_element_by_id('com.offcn.yidongzixishi:id/et_pwd').send_keys('bamboo1997')
            driver.find_element_by_xpath('//android.widget.Button[@index="5" and @text="立即登录"]').click()

            tb = driver.find_element_by_id('com.offcn.yidongzixishi:id/headTitle').text

            self.assertEqual('选择科目', tb, msg='登录不成功')

        except AssertionError:
            driver.save_screenshot(f'./pics/{self.cls_name}_{mtd_name}_登录不成功.png')
            raise

        except Exception:
            driver.save_screenshot(f'./pics/{self.cls_name}_{mtd_name}_其他错误.png')
            raise



