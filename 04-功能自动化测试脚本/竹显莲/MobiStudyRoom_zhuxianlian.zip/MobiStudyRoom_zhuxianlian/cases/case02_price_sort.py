import time
import unittest
import sys
from tools import open_app


class Price(unittest.TestCase):
    '''验证价格正序排序是否正确'''
    def setUp(self):
        driver = open_app()
        self.driver = driver
        self.cls_name = self.__class__.__name__

    def tearDown(self):
        time.sleep(3)
        self.driver.quit()

    def test_case(self):
        driver = self.driver
        mtd_name = sys._getframe().f_code.co_name

        try:

            driver.find_element_by_id('com.offcn.yidongzixishi:id/skip').click()
            driver.find_element_by_id('com.offcn.yidongzixishi:id/et_phone').send_keys('18336281141')
            driver.find_element_by_id('com.offcn.yidongzixishi:id/et_pwd').send_keys('bamboo1997')
            driver.find_element_by_xpath('//android.widget.Button[@index="5" and @text="立即登录"]').click()
            driver.find_elements_by_id('com.offcn.yidongzixishi:id/llExam')[0].click()

            # 取消广告弹窗
            driver.find_element_by_id('com.offcn.yidongzixishi:id/cancel').click()

            driver.find_element_by_id('com.offcn.yidongzixishi:id/rl_coach').click()
            driver.find_element_by_id('com.offcn.yidongzixishi:id/rlSort').click()
            driver.find_elements_by_id('com.offcn.yidongzixishi:id/textName')[2].click()

            prices = driver.find_elements_by_id('com.offcn.yidongzixishi:id/coursePrice')

            lst = []
            for i in prices:
                lst.append(float(i.text.split('￥')[1]))

            lst1 = lst
            lst1.sort()
            self.assertEqual(lst, lst1)

        except AssertionError:
            driver.save_screenshot(f'./pics/{self.cls_name}_{mtd_name}_价格排序错误.png')
            raise

        except Exception:
            driver.save_screenshot(f'./pics/{self.cls_name}_{mtd_name}_其他错误.png')
            raise




