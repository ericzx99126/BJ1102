import unittest
import HTMLTestReportCN
import time


suite2 = unittest.defaultTestLoader.discover(start_dir='./cases/', pattern='case*.py')

ts = time.strftime('%Y%m%d_%H%M')

runner2 = HTMLTestReportCN.HTMLTestRunner(stream=open('./reports/report_%s.html' % ts, 'wb'),
                                          title='iWebShop自动化测试报告',
                                          description='本测试覆盖了iWebShop所有主要功能、主要流程，现有用例666条',
                                          tester='小猪')

runner2.run(suite2)
